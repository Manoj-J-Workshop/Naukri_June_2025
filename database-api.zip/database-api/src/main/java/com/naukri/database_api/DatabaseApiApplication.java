package com.naukri.database_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseApiApplication.class, args);
	}

}
